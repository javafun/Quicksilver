﻿define("epi-ecf-ui/widget/CatalogContentSelector", [
    // dojo
    "dojo/_base/declare",
    // epi
    "epi/dependency",
    "epi/shell/TypeDescriptorManager",
    "epi-cms/widget/ContentSelector",
    "epi-ecf-ui/contentediting/ModelSupport",
    "epi-ecf-ui/widget/_CatalogContentSelectorTreeMixin"
], function (
    // dojo
    declare,
    // epi
    dependency,
    TypeDescriptorManager,
    ContentSelector,
    ModelSupport,
    _CatalogContentSelectorTreeMixin
) {
        return declare([ContentSelector, _CatalogContentSelectorTreeMixin], {
            postMixInProperties: function () {
                this.inherited(arguments);

                this._relationStore = this._relationStore || dependency.resolve("epi.storeregistry").get("epi.commerce.relation");
            },

            _updateDisplayNode: function (content) {
                // summary:
                //      Updated each time a content selected from content tree, and then confirmed by dialog's action.
                // tags:
                //      protected extensions

                this.inherited(arguments);

                if (!content) {
                    return;
                }

                if (content.contentLink && TypeDescriptorManager.isBaseTypeIdentifier(content.typeIdentifier, ModelSupport.contentTypeIdentifier.variationContent)) {
                    this._relationStore.query({ referenceId: content.contentLink, requestMode: ModelSupport.relationRequestMode.byTarget }).then(function (relations) {
                        this._contextualParentLink = relations instanceof Array && relations.length > 0 ? relations[0].source : null;
                    }.bind(this));
                }
            },

            _getDialog: function () {
                // tags:
                //      protected extensions

                var dialog = this.inherited(arguments);
                if (this.dialog && this.contentSelectorDialog) {
                    this._setupContentSelectorTree(this.contentSelectorDialog.tree);
                }

                return dialog;
            }
        });
    });