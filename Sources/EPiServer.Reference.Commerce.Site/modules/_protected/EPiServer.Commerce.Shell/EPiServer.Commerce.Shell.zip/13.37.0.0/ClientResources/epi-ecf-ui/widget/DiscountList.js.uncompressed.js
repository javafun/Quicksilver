require({cache:{
'url:epi-ecf-ui/widget/viewmodel/templates/DatePeriodColumnHeader.html':"﻿<h1>${headingLabel}</h1>\r\n<h2>${fromDate} - ${toDate}</h2>"}});
﻿define("epi-ecf-ui/widget/DiscountList", [
// dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/aspect",
    "dojo/dom-class",
    "dojo/html",
    "dojo/query",
    "dojo/promise/all",
    "dojo/string",
    "dojo/when",
// epi
    "epi/datetime",
// epi-cms
    "epi-cms/core/ContentReference",
// epi-ecf-ui
    "../MarketingUtils",
    "./_ConfirmDiscardChangesMixin",
    "./_MarketingListBase",
    "./DiscountSelector",
    "./viewmodel/DiscountListModel",
// resources
    "epi/i18n!epi/nls/commerce.widget.marketingitemlist",
    "epi/i18n!epi/nls/commerce.widget.marketingtoolbar",
    "dojo/text!./viewmodel/templates/DatePeriodColumnHeader.html"
], function (
// dojo
    array,
    declare,
    lang,
    aspect,
    domClass,
    html,
    query,
    all,
    dojoString,
    when,
// epi
    epiDate,
// epi-cms
    ContentReference,
// epi-ecf-ui
    MarketingUtils,
    _ConfirmDiscardChangesMixin,
    _MarketingListBase,
    DiscountSelector,
    DiscountListModel,
// resources
    marketingResources,
    marketingToolbarResources,
    datePeriodColumnHeaderTemplate
) {
    return declare([_MarketingListBase, _ConfirmDiscardChangesMixin], {
        // summary:
        //      A widget to list all promotions
        // tags:
        //      public

        // contextChangeEvent: [public] string
        //      Disable the double click action to grid item.
        contextChangeEvent: "",

        // typeIdentifiers: [public] Array
        //      Overrides base class properties in order to get promotion data only.
        typeIdentifiers: [
            MarketingUtils.contentTypeIdentifier.promotionData
        ],

        _discountSelectorDialog: null,

        postCreate: function () {
            this.inherited(arguments);

            domClass.add(this.grid.domNode, "epi-discount-list");
        },

        refresh: function (enabled) {
            // summary:
            //      Turn on/off grid's on demand load feature.
            // enabled: [bool]
            //      Flag to indicated that the grid should query to server or not
            // tags:
            //      public

            this.grid.set("store", enabled ? this.store : null, this.getQuery());
        },

        createModel: function () {
            // tags:
            //      public, extensions

            return new DiscountListModel({ store: this.store });
        },

        getListSettings: function () {
            // summary:
            //      Override grid's settings
            // tags:
            //      public, extensions

            var self = this,
                baseSettings = this.inherited(arguments);

            return lang.mixin(baseSettings, {
                dndParams: {
                    alwaysCopy: false,
                    accept: this.typeIdentifiers,
                    // Completely disable the grid's copy function by always returning false for the copyState
                    copyState: function (copyKeyPressed, self) { return false; }
                },
                showHeader: false,
                onContextMenuClick: function (e) {
                    this.inherited(arguments);

                    self.onContextMenuClick(e);
                },
                renderArray: function () {
                    return when(this.inherited(arguments), function (results) {
                        // After calling the inherited renderArray function we clear the noDataNode.
                        // This forces the grid to create a new node every time a campaign does not have any promotion.
                        self.grid.noDataNode = null;

                        var items = [];
                        for (var i = 0, length = results.length; i < length; i++) {
                            var row = results[i],
                                item = self.grid.row(row).data;
                            items.push(item);

                            domClass.add(row, [self.getItemClass(item), self.getItemStatusClass(item)]);
                            var orderCell = query(".field-order", row)[0];
                            if (orderCell) {
                                html.set(orderCell, (row.rowIndex + 1).toString());
                            }
                        }
                        self.model.set("items", items);

                        return results;
                    });
                }
            });
        },

        getQuery: function () {
            // tags:
            //      public, extensions

            var baseQuery = this.inherited(arguments);

            return lang.delegate(baseQuery, {
                query: this.model.queryName,
                referenceId: this.model.campaignRootFolder
            });
        },

        onContextMenuClick: function (e) {
            // summary:
            //      Setup command model of selected row.
            // tags:
            //      public, extensions

            this.inherited(arguments);

            this.model.updateCommandModel({ currentRowItem: this.grid.row(e).data });
        },

        setupEvents: function () {
            // tags:
            //      public, extensions

            this.own(
                aspect.after(this.grid.dndSource, "onDropData", this._onDndDrop.bind(this), true),
                this.model.on("item-moved", this._updateGrid.bind(this)),
                this.model.on("items-saved", lang.hitch(this, this.refresh, true))
            );
        },

        save: function () {
            // summary:
            //      Call save priority data.
            // return:
            //      Deferred object.
            // tags:
            //      publish

            return this.model.save();
        },

        _onDndDrop: function (dndData, source, nodes, copy) {
            // summary:
            //      Topic event processor for /dnd/drop, called to finish the DnD operation.
            // tags:
            //      private

            if (!this.grid.dndSource.current
                || this.grid.dndSource !== source) {
                return;
            }

            this.model.moveItem(dndData[0].data, this.grid.dndSource.getItem(this.grid.dndSource.current.id).data, this.grid.dndSource.before);
        },

        clearItems: function () {
            // summary:
            //      Clear the local representation of the items collection.
            // tags:
            //      Public

            this.model.items = [];
        },

        _updateGrid: function () {
            // summary:
            //      Update the grid.
            // tags:
            //      private

            if (!this.grid || !this.model) {
                return;
            }

            var items = this.model.get("items");
            if (items) {
                this.refresh(false);
                this.grid.renderArray(items);
            }
        },

        getColumnSettings: function () {
            // tags:
            //      public, extensions

            return {
                order: {
                    className: "epi-columnVeryNarrow epi-text--large",
                    sortable: false
                },
                name: {
                    className: "epi-grid--20",
                    get: this.model._getNameModel.bind(this.model),
                    formatter: this._getNameHtml,
                    sortable: false
                },
                daterange: {
                    className: "epi-grid-column--centered",
                    get: this.model._getStatusModel.bind(this.model),
                    formatter: this._getStatusHtml,
                    sortable: false
                },
                campaign: {
                    className: "epi-grid--20 epi-grid-column--centered",
                    get: function (item) {
                        return item.properties.campaignName;
                    },
                    sortable: false
                },
                exclusion: {
                    className: "epi-grid-column--left",
                    renderCell: function (item) {
                        return this._getDiscountSelector(item).domNode;
                    }.bind(this),
                    sortable: false
                }
            };
        },

        _getDiscountSelector: function (item) {
            // summary:
            //      Gets an instance of DiscountSelector widget.
            // item: [Object]
            //      Promotion data object.
            // tags:
            //      private

            var widget = new DiscountSelector({
                excludedLink: item.contentLink,
                dialog: this._discountSelectorDialog,
                ownDialog: false,
                store: this.model.store,
                campaignRootFolder: this.model.campaignRootFolder
            });

            if (!this._discountSelectorDialog) {
                this._discountSelectorDialog = widget.dialog;
                this.own(this._discountSelectorDialog);
            }

            widget._onChangeActive = false;
            var selectedLinks = item.properties.excludedItems || [],
                selectedContents = [];
            all(array.map(selectedLinks, function (contentLink) {
                return when(this.model.promotionDataStore.query({referenceId: contentLink}), function (content) {
                    if (content) {
                        if (ContentReference.compareIgnoreVersion(content.contentLink, this.model.campaignRootFolder)) {
                            content.name = marketingToolbarResources.allcampaigns;
                        }

                        selectedContents.push(content);
                    }
                }.bind(this));
            }, this)).then(function () {
                widget.set("value", selectedContents);
                widget._onChangeActive = true;
            });

            this.own(
                widget,
                widget.on("change", function (selectedItems) {
                    this.model.onSelectorValueChanged(item, selectedItems);
                }.bind(this))
            );

            return widget;
        },

        _getStatusHtml: function (model) {
            // tags:
            //      private

            return dojoString.substitute(datePeriodColumnHeaderTemplate, {
                headingLabel: marketingResources.status[model.statusLabelKey],
                fromDate: epiDate.toUserFriendlyString(model.validFrom, null, null, true),
                toDate: epiDate.toUserFriendlyString(model.validUntil, null, null, true)
            });
        }
    });
});