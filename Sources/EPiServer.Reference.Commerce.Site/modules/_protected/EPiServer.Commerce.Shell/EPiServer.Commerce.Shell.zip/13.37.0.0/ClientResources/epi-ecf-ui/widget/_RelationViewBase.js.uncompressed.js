﻿define("epi-ecf-ui/widget/_RelationViewBase", [
// dojo
    "dojo/_base/declare",
    "dojo/when",
// dijit
    "dijit/layout/_LayoutWidget",
// cms
    "epi/dependency",
// commerce
    "./_FullHeightContentMixin",
    "./BackToPreviousViewNotification",
    "epi-ecf-ui/contentediting/_ViewConfigurationsMixin"
], function (
// dojo
    declare,
    when,
// dijit
    _LayoutWidget,
// CMS
    dependency,
// commerce
    _FullHeightContentMixin,
    BackToPreviousViewNotification,
    _ViewConfigurationsMixin
) {

    return declare([_LayoutWidget, _FullHeightContentMixin, _ViewConfigurationsMixin], {
        // summary:
        //      Base class for the widgets that used to edit relations and associations.
        // tags:
        //      protected

        // Classes inheriting from this class needs to specify a dijit/layout/ContentPane.
        contentPane: null,

        _backToPreviousViewNotification: null,

        postCreate: function(){
            this.inherited(arguments);
            this._backToPreviousViewNotification = new BackToPreviousViewNotification();
            this.own(
                this._backToPreviousViewNotification.watch("notification", this._defaultNotificationWatchHandler.bind(this))
            );
        },

        _defaultNotificationWatchHandler: function (/*String*/name, /*Object*/oldValue, /*Object*/newValue) {
            // summary:
            //      Add/remove notification to/from notification bar
            // tags:
            //      private

            if (oldValue) {
                this.notificationBar.remove(oldValue);
            }

            if (newValue && newValue.content) {
                this.notificationBar.add(newValue);
            }
        },

        updateView: function (data, context) {
            // summary:
            //      Updates the view, to reflect data changes.(when opening this view second time)
            // tags:
            //      protected

            var update = function (accessMask) {
                this.toolbar.update({
                    currentContext: context,
                    viewConfigurations: {
                        availableViews: this.getAuthorizedViews(data.availableViews, accessMask),
                        viewName: data.viewName
                    }
                });
                this._backToPreviousViewNotification.showNotification();
            }.bind(this);

            if (data.accessMask != null) {
                update(data.accessMask);
                return;
            }

            this._store = this._store || dependency.resolve("epi.storeregistry").get("epi.cms.content.light");
            when(this._store.get(context.id)).then(function (content) {
                update(content.accessMask);
            }.bind(this));
        },

        resize: function () {
            // summary:
            //      Resize this widget to the given dimensions.
            // tags:
            //      protected
            this.inherited(arguments);

            // make the content 100% height its container
            this._setHeight(this.contentPane.domNode);
        }
    });
});